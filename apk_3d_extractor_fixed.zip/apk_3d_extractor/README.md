# 🎲 APK 3D Asset Extractor
**by Kakashi**

APK files ke andar chhupe 3D models, textures, audio aur assets extract karo — **bina ek line code decompile kiye!**

---

## ✨ Features

| Feature | Detail |
|---------|--------|
| 🎲 3D Models | OBJ, FBX, GLB, GLTF, DAE, 3DS, STL, PLY, BLEND... |
| 🖼️ Textures | PNG, JPG, TGA, DDS, PVR, KTX, ASTC, HDR, EXR... |
| 🔊 Audio | MP3, WAV, OGG, AAC, FLAC, OPUS... |
| ✨ Shaders | GLSL, VERT, FRAG, HLSL, Metal shaders |
| 🎮 Unity Assets | .assets, .bundle, AssetBundle files |
| 🌐 Scenes | Unity scene, Godot .tscn, .tres files |
| 👁️ 3D Preview | GLB/GLTF files in-app preview (rotate, zoom) |
| 💾 Export | Download/APK_3D_Assets mein save karo |

---

## 🚀 Setup Kaise Karo

### Requirements
- Flutter 3.x
- Android SDK (minSdk 21 = Android 5.0+)
- Internet permission (model_viewer ke liye)

### Steps

```bash
# 1. Project unzip karo
unzip apk_3d_extractor.zip
cd apk_3d_extractor

# 2. Dependencies install karo
flutter pub get

# 3. Android pe run karo
flutter run

# 4. Release APK banao
flutter build apk --release
```

### Agar model_viewer_plus issue aaye:
`android/app/build.gradle` mein check karo:
```groovy
minSdkVersion 21
```

---

## 📱 App Use Karne Ka Tarika

1. **APK Select Karo** — File picker se koi bhi `.apk` file choose karo
2. **Extract Button** — Automatic ZIP extract hoga (code skip hoga)
3. **Assets Dekhho** — Category wise filter karo (3D Models, Textures, etc.)
4. **Preview** — GLB/GLTF files ko 3D mein dekho (rotate, zoom, pan)
5. **Export** — Single ya multiple assets ko Downloads mein save karo

---

## 📂 Project Structure

```
lib/
├── main.dart                  → App entry + theme
├── models/
│   └── asset_item.dart        → Asset data class + extension registry
├── services/
│   ├── apk_extractor.dart     → ZIP extraction + export logic
│   └── asset_scanner.dart     → Directory scan + categorization
├── screens/
│   ├── home_screen.dart       → APK picker screen
│   ├── scan_screen.dart       → Progress + asset list
│   └── preview_screen.dart    → 3D model viewer
└── widgets/
    └── asset_card.dart        → Asset list card + filter tabs
```

---

## 🔧 Supported 3D Formats

| Format | Extension | Preview |
|--------|-----------|---------|
| GLTF Binary | `.glb` | ✅ In-app |
| GLTF JSON | `.gltf` | ✅ In-app |
| Wavefront | `.obj` | ❌ Export karo |
| Autodesk FBX | `.fbx` | ❌ Export karo |
| Collada | `.dae` | ❌ Export karo |
| 3DS Max | `.3ds` | ❌ Export karo |
| Blender | `.blend` | ❌ Export karo |
| STL | `.stl` | ❌ Export karo |
| VRM Avatar | `.vrm` | ❌ Export karo |

> 💡 **Tip:** Unity/Godot games mein assets often proprietary format mein hote hain. Unmein `.assets` aur `.bundle` files milenge — unhe AssetRipper tool se alag process karna hoga.

---

## ⚠️ Permissions

- `INTERNET` — model-viewer.js ke liye (3D preview)
- `READ_EXTERNAL_STORAGE` — APK file padhna
- `WRITE_EXTERNAL_STORAGE` — Assets save karna
- `MANAGE_EXTERNAL_STORAGE` — Android 11+ pe file access

---

## 📄 License

Personal use only. Respect other developers' work.
