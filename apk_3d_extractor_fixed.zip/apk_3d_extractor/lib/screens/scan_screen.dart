// ============================================================
// scan_screen.dart — APK extract karo aur assets dikhao
// ============================================================

import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../models/asset_item.dart';
import '../services/apk_extractor.dart';
import '../services/asset_scanner.dart';
import '../widgets/asset_card.dart';
import 'preview_screen.dart';

class ScanScreen extends StatefulWidget {
  final String apkPath;
  final String apkName;

  const ScanScreen({
    super.key,
    required this.apkPath,
    required this.apkName,
  });

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> with TickerProviderStateMixin {
  // Services
  final _extractor = ApkExtractor();
  final _scanner   = AssetScanner();

  // State
  _Phase _phase = _Phase.idle;
  double _progress = 0;
  String _statusMsg = '';
  String? _error;

  List<AssetItem> _allAssets = [];
  ScanStats? _stats;

  // Filter
  AssetCategory? _activeFilter; // null = sab dikhao
  final List<AssetCategory> _availableCategories = [];

  // Selection mode
  bool _selectMode = false;
  Set<String> _selectedPaths = {};

  // Export state
  bool _exporting = false;
  String? _exportMsg;

  // Tab controller for categories
  late final AnimationController _fadeCtrl;
  late final Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeIn);
    _startExtraction();
  }

  @override
  void dispose() {
    _extractor.cleanup();
    _fadeCtrl.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────────
  // Extraction logic
  // ─────────────────────────────────────────────

  void _startExtraction() async {
    setState(() => _phase = _Phase.extracting);

    // Stream se progress track karo
    await for (final p in _extractor.extract(widget.apkPath)) {
      if (!mounted) return;

      if (p.fraction < 0) {
        // Error
        setState(() {
          _phase = _Phase.error;
          _error = p.message;
        });
        return;
      }

      setState(() {
        _progress = p.fraction;
        _statusMsg = p.message;
      });
    }

    if (!mounted) return;

    // Scan assets
    setState(() {
      _phase = _Phase.scanning;
      _statusMsg = 'Assets scan ho rahi hain...';
    });

    await Future.delayed(const Duration(milliseconds: 200));

    if (_extractor.currentExtractDir == null) {
      setState(() {
        _phase = _Phase.error;
        _error = 'Extract directory nahi mila';
      });
      return;
    }

    final assets = _scanner.scan(_extractor.currentExtractDir!);
    final stats  = _scanner.statsFrom(assets);

    // Available categories collect karo
    final cats = <AssetCategory>{};
    for (final a in assets) cats.add(a.category);

    setState(() {
      _allAssets           = assets;
      _stats               = stats;
      _availableCategories.addAll(cats.toList()..sort((a, b) => a.index.compareTo(b.index)));
      _phase               = _Phase.done;
    });

    _fadeCtrl.forward();
  }

  // ─────────────────────────────────────────────
  // Filtered list
  // ─────────────────────────────────────────────

  List<AssetItem> get _filtered {
    if (_activeFilter == null) return _allAssets;
    return _allAssets.where((a) => a.category == _activeFilter).toList();
  }

  // ─────────────────────────────────────────────
  // Export
  // ─────────────────────────────────────────────

  Future<void> _exportSingle(AssetItem asset) async {
    setState(() { _exporting = true; _exportMsg = 'Export ho raha hai...'; });
    try {
      final result = await _extractor.exportAssets([asset]);
      _showSnack('✅ Saved: ${result.outputDir}');
    } catch (e) {
      _showSnack('❌ Error: $e');
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Future<void> _exportSelected() async {
    final toExport = _allAssets
        .where((a) => _selectedPaths.contains(a.fullPath))
        .toList();
    if (toExport.isEmpty) return;

    setState(() {
      _exporting  = true;
      _exportMsg  = 'Export ho rahe hain... (0/${toExport.length})';
    });

    final result = await _extractor.exportAssets(
      toExport,
      onProgress: (done, total) {
        if (mounted) setState(() => _exportMsg = 'Export... ($done/$total)');
      },
    );

    if (mounted) {
      setState(() {
        _exporting   = false;
        _selectMode  = false;
        _selectedPaths.clear();
      });
      _showSnack(
        result.allSuccess
            ? '✅ ${result.successCount} files → Downloads/APK_3D_Assets'
            : '⚠️ ${result.successCount} success, ${result.failCount} fail',
      );
    }
  }

  Future<void> _exportAll() async {
    if (_allAssets.isEmpty) return;
    setState(() {
      _exporting = true;
      _exportMsg = 'Sab export ho rahe hain...';
    });

    final result = await _extractor.exportAssets(
      _allAssets,
      onProgress: (done, total) {
        if (mounted) setState(() => _exportMsg = 'Export... ($done/$total)');
      },
    );

    if (mounted) {
      setState(() => _exporting = false);
      _showSnack(
        '✅ ${result.successCount} assets → Downloads/APK_3D_Assets',
      );
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  void _openPreview(AssetItem asset) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PreviewScreen(asset: asset),
      ),
    );
  }

  void _toggleSelect(AssetItem asset) {
    setState(() {
      if (_selectedPaths.contains(asset.fullPath)) {
        _selectedPaths.remove(asset.fullPath);
      } else {
        _selectedPaths.add(asset.fullPath);
      }
    });
  }

  // ─────────────────────────────────────────────
  // Build
  // ─────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A1A),
        leading: BackButton(color: Colors.white60),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.apkName,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            if (_phase == _Phase.done && _stats != null)
              Text(
                '${_stats!.total} assets mila',
                style: const TextStyle(color: Color(0xFF00D4FF), fontSize: 11),
              ),
          ],
        ),
        actions: [
          if (_phase == _Phase.done && _allAssets.isNotEmpty) ...[
            // Select mode toggle
            IconButton(
              icon: Icon(
                _selectMode ? Icons.check_box : Icons.check_box_outline_blank,
                color: _selectMode ? const Color(0xFF00D4FF) : Colors.white54,
              ),
              tooltip: 'Select Mode',
              onPressed: () => setState(() {
                _selectMode = !_selectMode;
                if (!_selectMode) _selectedPaths.clear();
              }),
            ),
            // Export all button
            IconButton(
              icon: const Icon(Icons.download_rounded, color: Color(0xFF7C4DFF)),
              tooltip: 'Sab Export Karo',
              onPressed: _exporting ? null : _exportAll,
            ),
          ],
        ],
      ),
      body: Column(
        children: [
          // ─── Progress / Error ───
          if (_phase == _Phase.extracting || _phase == _Phase.scanning)
            _ExtractingView(progress: _progress, message: _statusMsg),

          if (_phase == _Phase.error)
            _ErrorView(error: _error ?? 'Unknown error'),

          // ─── Results ───
          if (_phase == _Phase.done) ...[
            // Stats row
            if (_stats != null) _StatsRow(stats: _stats!),

            // Category filter tabs
            if (_availableCategories.isNotEmpty)
              _FilterBar(
                categories: _availableCategories,
                allCount: _allAssets.length,
                stats: _stats!,
                active: _activeFilter,
                onSelect: (cat) => setState(() => _activeFilter = cat),
              ),

            // Asset list
            Expanded(
              child: FadeTransition(
                opacity: _fadeAnim,
                child: _filtered.isEmpty
                    ? const _EmptyState()
                    : ListView.builder(
                        padding: const EdgeInsets.only(bottom: 100, top: 8),
                        itemCount: _filtered.length,
                        itemBuilder: (_, i) {
                          final asset = _filtered[i];
                          final isSelected = _selectedPaths.contains(asset.fullPath);
                          return AssetCard(
                            asset: asset,
                            isSelected: _selectMode && isSelected,
                            onTap: _selectMode
                                ? () => _toggleSelect(asset)
                                : asset.isPreviewable
                                    ? () => _openPreview(asset)
                                    : null,
                            onPreview: asset.isPreviewable
                                ? () => _openPreview(asset)
                                : null,
                            onExport: _exporting
                                ? null
                                : () => _exportSingle(asset),
                          );
                        },
                      ),
              ),
            ),
          ],
        ],
      ),

      // ─── Bottom export bar (select mode) ───
      bottomNavigationBar: (_selectMode && _selectedPaths.isNotEmpty)
          ? _SelectionBar(
              count: _selectedPaths.length,
              onExport: _exportSelected,
              onCancel: () => setState(() {
                _selectMode = false;
                _selectedPaths.clear();
              }),
            )
          : _exporting
              ? _ExportingBar(message: _exportMsg ?? 'Export ho raha hai...')
              : null,
    );
  }
}

// ─────────────────────────────────────────────
// Sub-states enum
// ─────────────────────────────────────────────

enum _Phase { idle, extracting, scanning, done, error }

// ─────────────────────────────────────────────
// Helper widgets
// ─────────────────────────────────────────────

class _ExtractingView extends StatelessWidget {
  final double progress;
  final String message;
  const _ExtractingView({required this.progress, required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(24),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: const Color(0xFF1A1A2E),
        border: Border.all(color: const Color(0xFF00D4FF).withOpacity(0.3)),
      ),
      child: Column(
        children: [
          // Animated 3D box icon
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.8, end: 1.0),
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
            builder: (_, v, __) => Transform.scale(
              scale: v,
              child: const Icon(
                Icons.unarchive_rounded,
                size: 52,
                color: Color(0xFF00D4FF),
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: progress > 0 ? progress : null,
              backgroundColor: Colors.white10,
              valueColor: const AlwaysStoppedAnimation(Color(0xFF00D4FF)),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            message,
            style: const TextStyle(color: Colors.white70, fontSize: 13),
            textAlign: TextAlign.center,
          ),
          if (progress > 0)
            Text(
              '${(progress * 100).toInt()}%',
              style: const TextStyle(
                color: Color(0xFF00D4FF),
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
        ],
      ),
    );
  }
}

class _StatsRow extends StatelessWidget {
  final ScanStats stats;
  const _StatsRow({required this.stats});

  @override
  Widget build(BuildContext context) {
    final models = stats.countOf(AssetCategory.model3d);
    final textures = stats.countOf(AssetCategory.texture);
    final audio = stats.countOf(AssetCategory.audio);

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(
          colors: [
            const Color(0xFF00D4FF).withOpacity(0.08),
            const Color(0xFF7C4DFF).withOpacity(0.08),
          ],
        ),
        border: Border.all(color: const Color(0xFF00D4FF).withOpacity(0.2)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _Stat('🎲', '$models', '3D Models'),
          _Vdivider(),
          _Stat('🖼️', '$textures', 'Textures'),
          _Vdivider(),
          _Stat('🔊', '$audio', 'Audio'),
          _Vdivider(),
          _Stat('📦', stats.totalSizeLabel, 'Total'),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String emoji;
  final String value;
  final String label;
  const _Stat(this.emoji, this.value, this.label);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(emoji, style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: const TextStyle(color: Colors.white38, fontSize: 10),
        ),
      ],
    );
  }
}

class _Vdivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) =>
      Container(width: 1, height: 36, color: Colors.white12);
}

class _FilterBar extends StatelessWidget {
  final List<AssetCategory> categories;
  final int allCount;
  final ScanStats stats;
  final AssetCategory? active;
  final void Function(AssetCategory?) onSelect;

  const _FilterBar({
    required this.categories,
    required this.allCount,
    required this.stats,
    required this.active,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 52,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        children: [
          // "Sab" tab
          CategoryTab(
            category: null,
            count: allCount,
            isActive: active == null,
            onTap: () => onSelect(null),
          ),
          ...categories.map((cat) => CategoryTab(
            category: cat,
            count: stats.countOf(cat),
            isActive: active == cat,
            onTap: () => onSelect(active == cat ? null : cat),
          )),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('😢', style: TextStyle(fontSize: 48)),
          SizedBox(height: 12),
          Text(
            'Is category mein koi asset nahi mila',
            style: TextStyle(color: Colors.white54, fontSize: 14),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String error;
  const _ErrorView({required this.error});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(24),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: const Color(0xFFFF5252).withOpacity(0.1),
        border: Border.all(color: const Color(0xFFFF5252).withOpacity(0.4)),
      ),
      child: Column(
        children: [
          const Icon(Icons.error_outline, color: Color(0xFFFF5252), size: 40),
          const SizedBox(height: 12),
          const Text(
            'Extract nahi ho saka!',
            style: TextStyle(
                color: Color(0xFFFF5252),
                fontSize: 16,
                fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            error,
            style: const TextStyle(color: Colors.white54, fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _SelectionBar extends StatelessWidget {
  final int count;
  final VoidCallback onExport;
  final VoidCallback onCancel;

  const _SelectionBar({
    required this.count,
    required this.onExport,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        border: const Border(top: BorderSide(color: Color(0xFF00D4FF), width: 1)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '$count items selected',
              style: const TextStyle(color: Colors.white70),
            ),
          ),
          TextButton(
            onPressed: onCancel,
            child: const Text('Cancel', style: TextStyle(color: Colors.white38)),
          ),
          const SizedBox(width: 8),
          ElevatedButton.icon(
            onPressed: onExport,
            icon: const Icon(Icons.download_rounded, size: 18),
            label: const Text('Export Selected'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF7C4DFF),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      ),
    );
  }
}

class _ExportingBar extends StatelessWidget {
  final String message;
  const _ExportingBar({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      color: const Color(0xFF1A1A2E),
      child: Row(
        children: [
          const SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation(Color(0xFF7C4DFF)),
            ),
          ),
          const SizedBox(width: 12),
          Text(message, style: const TextStyle(color: Colors.white60)),
        ],
      ),
    );
  }
}
