// ============================================================
// home_screen.dart — Main screen, APK select karo yahan se
// ============================================================

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'scan_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  late final AnimationController _glowCtrl;
  late final AnimationController _rotCtrl;
  late final Animation<double> _glowAnim;
  late final Animation<double> _rotAnim;

  String? _apkPath;
  String? _apkName;
  int?   _apkSize;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _rotCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    _glowAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );

    _rotAnim = Tween<double>(begin: 0, end: 1).animate(_rotCtrl);
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _rotCtrl.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────────
  // APK Select karo
  // ─────────────────────────────────────────────

  Future<void> _pickApk() async {
    // Android 11+ ke liye MANAGE_EXTERNAL_STORAGE chahiye
    final manageStatus = await Permission.manageExternalStorage.status;
    if (!manageStatus.isGranted) {
      await Permission.manageExternalStorage.request();
    }

    // Old Android ke liye READ_EXTERNAL_STORAGE
    final readStatus = await Permission.storage.status;
    if (!readStatus.isGranted) {
      await Permission.storage.request();
    }

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['apk'],
      dialogTitle: 'APK file choose karo',
      withReadStream: false,
    );

    if (result != null && result.files.single.path != null) {
      final file = result.files.single;
      setState(() {
        _apkPath = file.path!;
        _apkName = file.name;
        _apkSize = file.size;
      });
    }
  }

  void _startExtract() {
    if (_apkPath == null) return;
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, anim, __) => ScanScreen(
          apkPath: _apkPath!,
          apkName: _apkName!,
        ),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: anim,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.1),
              end: Offset.zero,
            ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOut)),
            child: child,
          ),
        ),
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }

  // ─────────────────────────────────────────────
  // UI
  // ─────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A1A),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.3),
            radius: 1.2,
            colors: [Color(0xFF0D1A2E), Color(0xFF0A0A1A)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ─── Header ───
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF00D4FF), Color(0xFF7C4DFF)],
                        ),
                      ),
                      child: const Icon(
                        Icons.view_in_ar_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                    ),
                    const SizedBox(width: 14),
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'APK 3D Extractor',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                        Text(
                          'by Kakashi',
                          style: TextStyle(
                            color: Color(0xFF00D4FF),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: const Color(0xFF00E676).withOpacity(0.15),
                        border: Border.all(
                          color: const Color(0xFF00E676).withOpacity(0.4),
                        ),
                      ),
                      child: const Text(
                        '✓ No Code',
                        style: TextStyle(
                          color: Color(0xFF00E676),
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // ─── 3D Animated Icon ───
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AnimatedBuilder(
                        animation: Listenable.merge([_glowAnim, _rotAnim]),
                        builder: (_, __) {
                          return Stack(
                            alignment: Alignment.center,
                            children: [
                              // Outer glow ring
                              Container(
                                width: 200 * _glowAnim.value,
                                height: 200 * _glowAnim.value,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: RadialGradient(
                                    colors: [
                                      const Color(0xFF00D4FF)
                                          .withOpacity(0.15 * _glowAnim.value),
                                      Colors.transparent,
                                    ],
                                  ),
                                ),
                              ),
                              // Rotating dashed border
                              Transform.rotate(
                                angle: _rotAnim.value * 6.28,
                                child: Container(
                                  width: 150,
                                  height: 150,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: const Color(0xFF00D4FF)
                                          .withOpacity(0.3),
                                      width: 1.5,
                                    ),
                                  ),
                                ),
                              ),
                              // Center icon
                              Container(
                                width: 110,
                                height: 110,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: const LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      Color(0xFF00D4FF),
                                      Color(0xFF7C4DFF),
                                    ],
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xFF00D4FF)
                                          .withOpacity(0.4 * _glowAnim.value),
                                      blurRadius: 30,
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.view_in_ar_rounded,
                                  color: Colors.white,
                                  size: 52,
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 28),
                      const Text(
                        'APK ke andar ke\n3D Models Extract Karo',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          height: 1.3,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Code decompile nahi hoga — sirf\nassets, textures aur 3D models!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.5),
                          fontSize: 14,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // ─── Feature chips ───
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 8,
                  runSpacing: 8,
                  children: const [
                    _Chip('🎲 OBJ / FBX / GLB', 0xFF00D4FF),
                    _Chip('🖼️ Textures & DDS', 0xFF7C4DFF),
                    _Chip('🔊 Audio Files', 0xFF00E676),
                    _Chip('✨ GLSL Shaders', 0xFFFFD740),
                    _Chip('🎮 Unity Assets', 0xFF40C4FF),
                    _Chip('🌐 Godot Scenes', 0xFFFF6D00),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // ─── APK info (after selection) ───
              if (_apkPath != null) _ApkInfoCard(
                name: _apkName!,
                path: _apkPath!,
                size: _apkSize ?? 0,
                onClear: () => setState(() {
                  _apkPath = null;
                  _apkName = null;
                  _apkSize = null;
                }),
              ),

              // ─── Buttons ───
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
                child: _apkPath == null
                    ? _PrimaryButton(
                        label: 'APK File Select Karo',
                        icon: Icons.folder_open_rounded,
                        color: const Color(0xFF00D4FF),
                        onTap: _pickApk,
                      )
                    : Row(
                        children: [
                          Expanded(
                            child: _OutlineButton(
                              label: 'Change',
                              icon: Icons.swap_horiz_rounded,
                              onTap: _pickApk,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            flex: 2,
                            child: _PrimaryButton(
                              label: 'Assets Extract Karo',
                              icon: Icons.download_for_offline_rounded,
                              color: const Color(0xFF7C4DFF),
                              onTap: _startExtract,
                            ),
                          ),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// Helper Widgets
// ─────────────────────────────────────────────

class _Chip extends StatelessWidget {
  final String label;
  final int color;
  const _Chip(this.label, this.color);

  @override
  Widget build(BuildContext context) {
    final c = Color(color);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: c.withOpacity(0.08),
        border: Border.all(color: c.withOpacity(0.35)),
      ),
      child: Text(
        label,
        style: TextStyle(color: c, fontSize: 12, fontWeight: FontWeight.w500),
      ),
    );
  }
}

class _ApkInfoCard extends StatelessWidget {
  final String name;
  final String path;
  final int size;
  final VoidCallback onClear;

  const _ApkInfoCard({
    required this.name,
    required this.path,
    required this.size,
    required this.onClear,
  });

  String get _sizeLabel {
    final mb = size / (1024 * 1024);
    return '${mb.toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: const Color(0xFF00D4FF).withOpacity(0.07),
        border: Border.all(color: const Color(0xFF00D4FF).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.android_rounded,
              color: Color(0xFF00D4FF), size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13)),
                const SizedBox(height: 2),
                Text(
                  _sizeLabel,
                  style: const TextStyle(color: Color(0xFF00D4FF), fontSize: 11),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, color: Colors.white38, size: 20),
            onPressed: onClear,
            padding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _PrimaryButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 20),
        label: Text(
          label,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 8,
          shadowColor: color.withOpacity(0.4),
        ),
      ),
    );
  }
}

class _OutlineButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _OutlineButton({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 54,
      child: OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 18),
        label: Text(label),
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white60,
          side: const BorderSide(color: Colors.white24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}
