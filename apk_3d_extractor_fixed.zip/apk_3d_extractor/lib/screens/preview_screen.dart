// ============================================================
// preview_screen.dart — GLB/GLTF 3D model preview screen
// model_viewer_plus use hota hai yahan
// ============================================================

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:model_viewer_plus/model_viewer_plus.dart';
import 'package:share_plus/share_plus.dart';
import '../models/asset_item.dart';
import '../services/apk_extractor.dart';

class PreviewScreen extends StatefulWidget {
  final AssetItem asset;

  const PreviewScreen({super.key, required this.asset});

  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  bool _autoRotate = true;
  bool _showInfo   = true;

  final _extractor = ApkExtractor();

  // Model viewer settings
  String get _src => 'file://${widget.asset.fullPath}';

  Future<void> _shareAsset() async {
    try {
      await Share.shareXFiles(
        [XFile(widget.asset.fullPath)],
        text: widget.asset.name,
      );
    } catch (e) {
      _showSnack('Share failed: $e');
    }
  }

  Future<void> _exportAsset() async {
    try {
      final result = await _extractor.exportAssets([widget.asset]);
      _showSnack('✅ Saved to: ${result.outputDir}');
    } catch (e) {
      _showSnack('❌ Error: $e');
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: BackButton(
          color: Colors.white,
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.asset.name,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          // Info toggle
          IconButton(
            icon: Icon(
              Icons.info_outline,
              color: _showInfo ? const Color(0xFF00D4FF) : Colors.white54,
            ),
            onPressed: () => setState(() => _showInfo = !_showInfo),
          ),
          // Share
          IconButton(
            icon: const Icon(Icons.share_rounded, color: Colors.white54),
            onPressed: _shareAsset,
          ),
          // Export
          IconButton(
            icon: const Icon(Icons.download_rounded, color: Color(0xFF7C4DFF)),
            onPressed: _exportAsset,
          ),
        ],
      ),
      body: Stack(
        children: [
          // ─── 3D Model Viewer ───
          _ModelView(
            src: _src,
            autoRotate: _autoRotate,
          ),

          // ─── Bottom info panel ───
          if (_showInfo)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: _InfoPanel(
                asset: widget.asset,
                autoRotate: _autoRotate,
                onAutoRotateToggle: () =>
                    setState(() => _autoRotate = !_autoRotate),
              ),
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
// 3D Model Viewer widget
// ─────────────────────────────────────────────

class _ModelView extends StatelessWidget {
  final String src;
  final bool autoRotate;

  const _ModelView({required this.src, required this.autoRotate});

  @override
  Widget build(BuildContext context) {
    return ModelViewer(
      src: src,
      alt: '3D Model',
      autoRotate: autoRotate,
      autoRotateDelay: 1000,
      cameraControls: true,
      backgroundColor: const Color(0xFF0A0A1A),
      shadowIntensity: 1,
      shadowSoftness: 1,
      exposure: 1.0,
      // Touch controls enable
      touchAction: TouchAction.panY,
    );
  }
}

// ─────────────────────────────────────────────
// Info panel at bottom
// ─────────────────────────────────────────────

class _InfoPanel extends StatelessWidget {
  final AssetItem asset;
  final bool autoRotate;
  final VoidCallback onAutoRotateToggle;

  const _InfoPanel({
    required this.asset,
    required this.autoRotate,
    required this.onAutoRotateToggle,
  });

  @override
  Widget build(BuildContext context) {
    final categoryColor = Color(asset.category.badgeColor);

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [
            const Color(0xFF0A0A1A),
            const Color(0xFF0A0A1A).withOpacity(0.95),
            Colors.transparent,
          ],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // File name + format badge
          Row(
            children: [
              Expanded(
                child: Text(
                  asset.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: categoryColor.withOpacity(0.2),
                  border: Border.all(color: categoryColor.withOpacity(0.5)),
                ),
                child: Text(
                  asset.formatName,
                  style: TextStyle(
                    color: categoryColor,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Metadata row
          Row(
            children: [
              _MetaChip('📦 ${asset.sizeLabel}'),
              const SizedBox(width: 8),
              _MetaChip(asset.relativePath, flex: true),
            ],
          ),
          const SizedBox(height: 12),

          // Control buttons
          Row(
            children: [
              // Auto-rotate toggle
              _ControlBtn(
                icon: Icons.rotate_right_rounded,
                label: 'Auto Rotate',
                active: autoRotate,
                onTap: onAutoRotateToggle,
              ),
              const SizedBox(width: 8),
              _ControlBtn(
                icon: Icons.zoom_out_map_rounded,
                label: 'Pinch Zoom',
                active: true,
                onTap: () {},
              ),
              const SizedBox(width: 8),
              _ControlBtn(
                icon: Icons.touch_app_rounded,
                label: 'Drag Rotate',
                active: true,
                onTap: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final String text;
  final bool flex;
  const _MetaChip(this.text, {this.flex = false});

  @override
  Widget build(BuildContext context) {
    final child = Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: Colors.white.withOpacity(0.07),
        border: Border.all(color: Colors.white12),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.white54, fontSize: 11),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
    if (flex) return Expanded(child: child);
    return child;
  }
}

class _ControlBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _ControlBtn({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: active
              ? const Color(0xFF00D4FF).withOpacity(0.12)
              : Colors.white.withOpacity(0.05),
          border: Border.all(
            color: active
                ? const Color(0xFF00D4FF).withOpacity(0.4)
                : Colors.white12,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 14,
              color: active ? const Color(0xFF00D4FF) : Colors.white38,
            ),
            const SizedBox(width: 5),
            Text(
              label,
              style: TextStyle(
                color: active ? const Color(0xFF00D4FF) : Colors.white38,
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// Non-previewable file screen (OBJ, FBX, etc.)
// ─────────────────────────────────────────────

class NonPreviewableScreen extends StatelessWidget {
  final AssetItem asset;

  const NonPreviewableScreen({super.key, required this.asset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A1A),
        title: Text(asset.name,
            style: const TextStyle(color: Colors.white, fontSize: 14)),
        leading: const BackButton(color: Colors.white),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                asset.category.emoji,
                style: const TextStyle(fontSize: 64),
              ),
              const SizedBox(height: 24),
              Text(
                asset.name,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                asset.formatName,
                style: const TextStyle(
                    color: Color(0xFF00D4FF), fontSize: 14),
              ),
              const SizedBox(height: 4),
              Text(
                asset.sizeLabel,
                style: const TextStyle(color: Colors.white38, fontSize: 12),
              ),
              const SizedBox(height: 32),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: const Color(0xFF1A1A2E),
                  border: Border.all(color: Colors.white12),
                ),
                child: const Text(
                  '⚠️ Is format ka in-app preview available nahi hai.\n\n'
                  '✅ Aap ise export karke Blender, Maya, ya kisi bhi\n'
                  '3D software mein khol sakte ho!',
                  style: TextStyle(color: Colors.white60, fontSize: 13, height: 1.6),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
