// ============================================================
// asset_item.dart — Extracted asset ka data model
// ============================================================

/// APK ke andar milne wala ek asset file
class AssetItem {
  final String name;         // File ka naam (e.g., "hero.glb")
  final String relativePath; // APK ke andar ka path
  final String fullPath;     // Device par actual path
  final String extension;    // File extension (e.g., ".glb")
  final int sizeBytes;       // File size bytes mein
  final AssetCategory category; // Kaunsi category ka asset hai

  bool isSelected;

  AssetItem({
    required this.name,
    required this.relativePath,
    required this.fullPath,
    required this.extension,
    required this.sizeBytes,
    required this.category,
    this.isSelected = false,
  });

  /// File size human-readable format mein
  String get sizeLabel {
    if (sizeBytes < 1024) return '$sizeBytes B';
    if (sizeBytes < 1024 * 1024) {
      return '${(sizeBytes / 1024).toStringAsFixed(1)} KB';
    }
    if (sizeBytes < 1024 * 1024 * 1024) {
      return '${(sizeBytes / (1024 * 1024)).toStringAsFixed(2)} MB';
    }
    return '${(sizeBytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  /// Kya yeh file 3D preview kar sakta hai?
  bool get isPreviewable {
    return extension == '.glb' || extension == '.gltf';
  }

  /// Format ka full naam
  String get formatName {
    return AssetRegistry.formatName(extension) ?? extension.toUpperCase();
  }
}

// ─────────────────────────────────────────────
// Asset Categories
// ─────────────────────────────────────────────

enum AssetCategory {
  model3d,    // 3D models
  texture,    // Images/textures
  audio,      // Sound files
  shader,     // GLSL/HLSL shaders
  scene,      // Scene files (Unity, Godot)
  animation,  // Animation files
  unityAsset, // Unity asset bundles
  video,      // Video files
  other,      // Everything else
}

extension AssetCategoryExt on AssetCategory {
  String get label {
    switch (this) {
      case AssetCategory.model3d:    return '3D Model';
      case AssetCategory.texture:    return 'Texture';
      case AssetCategory.audio:      return 'Audio';
      case AssetCategory.shader:     return 'Shader';
      case AssetCategory.scene:      return 'Scene';
      case AssetCategory.animation:  return 'Animation';
      case AssetCategory.unityAsset: return 'Unity Asset';
      case AssetCategory.video:      return 'Video';
      case AssetCategory.other:      return 'Other';
    }
  }

  String get emoji {
    switch (this) {
      case AssetCategory.model3d:    return '🎲';
      case AssetCategory.texture:    return '🖼️';
      case AssetCategory.audio:      return '🔊';
      case AssetCategory.shader:     return '✨';
      case AssetCategory.scene:      return '🌐';
      case AssetCategory.animation:  return '🎬';
      case AssetCategory.unityAsset: return '🎮';
      case AssetCategory.video:      return '🎥';
      case AssetCategory.other:      return '📄';
    }
  }

  /// Is category ka badge color
  int get badgeColor {
    switch (this) {
      case AssetCategory.model3d:    return 0xFF00D4FF;
      case AssetCategory.texture:    return 0xFF7C4DFF;
      case AssetCategory.audio:      return 0xFF00E676;
      case AssetCategory.shader:     return 0xFFFFD740;
      case AssetCategory.scene:      return 0xFFFF6D00;
      case AssetCategory.animation:  return 0xFFE040FB;
      case AssetCategory.unityAsset: return 0xFF40C4FF;
      case AssetCategory.video:      return 0xFFFF5252;
      case AssetCategory.other:      return 0xFF78909C;
    }
  }
}

// ─────────────────────────────────────────────
// File Extension Registry
// ─────────────────────────────────────────────

class AssetRegistry {
  // 3D Model formats
  static const Map<String, String> models = {
    '.obj':   'Wavefront OBJ',
    '.fbx':   'Autodesk FBX',
    '.gltf':  'GLTF 2.0',
    '.glb':   'GLTF Binary',
    '.dae':   'Collada DAE',
    '.3ds':   '3DS Max Model',
    '.stl':   'STL Mesh',
    '.ply':   'PLY Point Cloud',
    '.blend': 'Blender Model',
    '.abc':   'Alembic Cache',
    '.usdz':  'USD Scene',
    '.vrm':   'VRM Avatar',
    '.x3d':   'X3D Model',
    '.wrl':   'VRML Model',
    '.lwo':   'LightWave Object',
    '.lws':   'LightWave Scene',
    '.mesh':  '3D Mesh Data',
    '.bin':   'Binary Mesh',    // GLTF .bin buffers
    '.c4d':   'Cinema 4D Model',
    '.ma':    'Maya ASCII',
    '.mb':    'Maya Binary',
    '.max':   '3DS Max Scene',
    '.skp':   'SketchUp Model',
    '.igs':   'IGES CAD',
    '.stp':   'STEP CAD',
  };

  // Texture/Image formats
  static const Map<String, String> textures = {
    '.png':   'PNG Image',
    '.jpg':   'JPEG Image',
    '.jpeg':  'JPEG Image',
    '.tga':   'Targa Texture',
    '.dds':   'DirectX Texture',
    '.pvr':   'PowerVR Texture',
    '.ktx':   'KTX Texture',
    '.astc':  'ASTC Compressed',
    '.webp':  'WebP Image',
    '.bmp':   'Bitmap Image',
    '.hdr':   'HDR Environment',
    '.exr':   'OpenEXR',
    '.psd':   'Photoshop File',
    '.tiff':  'TIFF Image',
    '.tif':   'TIFF Image',
    '.ktx2':  'KTX2 Texture',
    '.basis': 'Basis Universal',
    '.cubemap': 'Cubemap Texture',
    '.raw':   'Raw Texture Data',
  };

  // Audio formats
  static const Map<String, String> audio = {
    '.mp3':  'MP3 Audio',
    '.wav':  'WAV Audio',
    '.ogg':  'OGG Vorbis',
    '.aac':  'AAC Audio',
    '.flac': 'FLAC Lossless',
    '.m4a':  'M4A Audio',
    '.opus': 'Opus Audio',
    '.mid':  'MIDI',
    '.xm':   'XM Module',
    '.mod':  'MOD Tracker',
  };

  // Shader formats
  static const Map<String, String> shaders = {
    '.glsl':   'GLSL Shader',
    '.vert':   'Vertex Shader',
    '.frag':   'Fragment Shader',
    '.shader': 'Unity Shader',
    '.hlsl':   'HLSL Shader',
    '.cg':     'CG Shader',
    '.metal':  'Metal Shader',
    '.comp':   'Compute Shader',
    '.geom':   'Geometry Shader',
  };

  // Scene/Level formats
  static const Map<String, String> scenes = {
    '.unity':  'Unity Scene',
    '.prefab': 'Unity Prefab',
    '.tscn':   'Godot Scene',
    '.scn':    'Binary Scene',
    '.tres':   'Godot Resource',
    '.level':  'Level Data',
    '.map':    'Map File',
    '.bsp':    'BSP Level',
  };

  // Animation formats
  static const Map<String, String> animations = {
    '.anim':   'Unity Animation',
    '.bvh':    'Motion Capture',
    '.motion': 'Motion Data',
    '.anm':    'Animation File',
  };

  // Unity/Engine asset bundles
  static const Map<String, String> unityAssets = {
    '.assets':      'Unity Asset File',
    '.bundle':      'Unity Asset Bundle',
    '.assetbundle': 'Asset Bundle',
    '.unity3d':     'Unity3D Package',
    '.pck':         'Godot Pack File',
    '.pak':         'Unreal PAK Archive',
    '.asset':       'Asset File',
    '.manifest':    'Asset Manifest',
    '.resource':    'Resource File',
    '.resS':        'Resource Stream',
  };

  // Video formats
  static const Map<String, String> videos = {
    '.mp4':  'MP4 Video',
    '.webm': 'WebM Video',
    '.ogv':  'OGV Video',
    '.avi':  'AVI Video',
    '.mov':  'QuickTime Video',
  };

  /// Extension se format naam milta hai
  static String? formatName(String ext) {
    final e = ext.toLowerCase();
    return models[e] ?? textures[e] ?? audio[e] ?? shaders[e] ??
           scenes[e] ?? animations[e] ?? unityAssets[e] ?? videos[e];
  }

  /// Extension se category determine karo
  static AssetCategory? categoryOf(String ext) {
    final e = ext.toLowerCase();
    if (models.containsKey(e))      return AssetCategory.model3d;
    if (textures.containsKey(e))    return AssetCategory.texture;
    if (audio.containsKey(e))       return AssetCategory.audio;
    if (shaders.containsKey(e))     return AssetCategory.shader;
    if (scenes.containsKey(e))      return AssetCategory.scene;
    if (animations.containsKey(e))  return AssetCategory.animation;
    if (unityAssets.containsKey(e)) return AssetCategory.unityAsset;
    if (videos.containsKey(e))      return AssetCategory.video;
    return null;
  }
}
