// ============================================================
// asset_card.dart — Asset list mein ek card
// ============================================================

import 'package:flutter/material.dart';
import '../models/asset_item.dart';

class AssetCard extends StatelessWidget {
  final AssetItem asset;
  final VoidCallback? onPreview;
  final VoidCallback? onExport;
  final VoidCallback? onTap;
  final bool isSelected;

  const AssetCard({
    super.key,
    required this.asset,
    this.onPreview,
    this.onExport,
    this.onTap,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    final categoryColor = Color(asset.category.badgeColor);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: const Color(0xFF1A1A2E),
          border: Border.all(
            color: isSelected
                ? categoryColor
                : categoryColor.withOpacity(0.25),
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected
              ? [BoxShadow(color: categoryColor.withOpacity(0.3), blurRadius: 12)]
              : null,
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              // Category icon + format badge
              _IconBlock(asset: asset, categoryColor: categoryColor),

              const SizedBox(width: 14),

              // File info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      asset.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          asset.formatName,
                          style: TextStyle(
                            color: categoryColor,
                            fontSize: 11,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '•',
                          style: TextStyle(color: Colors.white38, fontSize: 11),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          asset.sizeLabel,
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      asset.relativePath,
                      style: const TextStyle(
                        color: Colors.white30,
                        fontSize: 10,
                        fontFamily: 'monospace',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 8),

              // Action buttons
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Preview button (sirf GLB/GLTF ke liye)
                  if (asset.isPreviewable && onPreview != null)
                    _ActionBtn(
                      icon: Icons.view_in_ar_rounded,
                      color: const Color(0xFF00D4FF),
                      tooltip: '3D Preview',
                      onTap: onPreview!,
                    ),

                  if (asset.isPreviewable && onPreview != null)
                    const SizedBox(height: 6),

                  // Export button
                  if (onExport != null)
                    _ActionBtn(
                      icon: Icons.download_rounded,
                      color: const Color(0xFF7C4DFF),
                      tooltip: 'Export',
                      onTap: onExport!,
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────

class _IconBlock extends StatelessWidget {
  final AssetItem asset;
  final Color categoryColor;

  const _IconBlock({required this.asset, required this.categoryColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 52,
      height: 52,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: categoryColor.withOpacity(0.12),
        border: Border.all(color: categoryColor.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            asset.category.emoji,
            style: const TextStyle(fontSize: 20),
          ),
          const SizedBox(height: 2),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: categoryColor.withOpacity(0.2),
            ),
            child: Text(
              asset.extension.replaceAll('.', '').toUpperCase(),
              style: TextStyle(
                color: categoryColor,
                fontSize: 8,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String tooltip;
  final VoidCallback onTap;

  const _ActionBtn({
    required this.icon,
    required this.color,
    required this.tooltip,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.15),
            border: Border.all(color: color.withOpacity(0.4)),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// Category filter tab
// ─────────────────────────────────────────────

class CategoryTab extends StatelessWidget {
  final AssetCategory? category; // null = "Sab"
  final int count;
  final bool isActive;
  final VoidCallback onTap;

  const CategoryTab({
    super.key,
    required this.category,
    required this.count,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final label = category?.label ?? 'Sab';
    final emoji = category?.emoji ?? '📦';
    final color = category != null
        ? Color(category!.badgeColor)
        : const Color(0xFF00D4FF);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: isActive ? color.withOpacity(0.2) : const Color(0xFF1A1A2E),
          border: Border.all(
            color: isActive ? color : color.withOpacity(0.3),
            width: isActive ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 14)),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isActive ? color : Colors.white60,
                fontSize: 12,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
              ),
            ),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: isActive ? color.withOpacity(0.3) : Colors.white.withOpacity(0.1),
              ),
              child: Text(
                '$count',
                style: TextStyle(
                  color: isActive ? color : Colors.white54,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
