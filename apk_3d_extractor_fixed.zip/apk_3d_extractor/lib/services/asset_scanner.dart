// ============================================================
// asset_scanner.dart — Extracted directory mein assets dhundho
// ============================================================

import 'dart:io';
import 'package:path/path.dart' as p;
import '../models/asset_item.dart';

class AssetScanner {
  // Yeh folders skip karo (code-related)
  static const _skipDirs = {
    'meta-inf', 'kotlin', 'okhttp3', 'com', 'org',
    'dagger', 'rx', 'retrofit', 'gson', 'proguard',
  };

  /// Directory scan karke saari assets return karo
  List<AssetItem> scan(
    String extractedDir, {
    Set<AssetCategory>? filterCategories, // null = sab
    int minSizeBytes = 0,
  }) {
    final dir = Directory(extractedDir);
    if (!dir.existsSync()) return [];

    final List<AssetItem> found = [];
    _walk(dir, found, extractedDir);

    var result = found.where((a) => a.sizeBytes >= minSizeBytes).toList();

    if (filterCategories != null && filterCategories.isNotEmpty) {
      result = result.where((a) => filterCategories.contains(a.category)).toList();
    }

    // Sort: 3D models pehle, phir size ke hisaab se
    result.sort((a, b) {
      if (a.category == AssetCategory.model3d &&
          b.category != AssetCategory.model3d) return -1;
      if (a.category != AssetCategory.model3d &&
          b.category == AssetCategory.model3d) return 1;
      return b.sizeBytes.compareTo(a.sizeBytes);
    });

    return result;
  }

  void _walk(Directory dir, List<AssetItem> found, String rootPath) {
    try {
      final entries = dir.listSync(recursive: false, followLinks: false);
      for (final e in entries) {
        if (e is File) {
          _checkFile(e, found, rootPath);
        } else if (e is Directory) {
          final name = p.basename(e.path).toLowerCase();
          // Code folders skip karo
          if (!_skipDirs.contains(name)) {
            _walk(e, found, rootPath);
          }
        }
      }
    } catch (_) {}
  }

  void _checkFile(File file, List<AssetItem> found, String rootPath) {
    final ext = p.extension(file.path).toLowerCase();
    if (ext.isEmpty) return;

    final category = AssetRegistry.categoryOf(ext);
    if (category == null) return;

    try {
      final stat = file.statSync();
      if (stat.size == 0) return; // Empty files skip karo

      final relativePath = file.path.replaceFirst(rootPath, '').replaceAll('\\', '/');

      found.add(AssetItem(
        name: p.basename(file.path),
        relativePath: relativePath,
        fullPath: file.path,
        extension: ext,
        sizeBytes: stat.size,
        category: category,
      ));
    } catch (_) {}
  }

  /// Stats calculate karo
  ScanStats statsFrom(List<AssetItem> assets) {
    final Map<AssetCategory, int> counts = {};
    final Map<AssetCategory, int> sizes = {};
    int totalSize = 0;

    for (final asset in assets) {
      counts[asset.category] = (counts[asset.category] ?? 0) + 1;
      sizes[asset.category] = (sizes[asset.category] ?? 0) + asset.sizeBytes;
      totalSize += asset.sizeBytes;
    }

    return ScanStats(
      total: assets.length,
      counts: counts,
      sizes: sizes,
      totalSizeBytes: totalSize,
    );
  }
}

class ScanStats {
  final int total;
  final Map<AssetCategory, int> counts;
  final Map<AssetCategory, int> sizes;
  final int totalSizeBytes;

  const ScanStats({
    required this.total,
    required this.counts,
    required this.sizes,
    required this.totalSizeBytes,
  });

  int countOf(AssetCategory cat) => counts[cat] ?? 0;

  String get totalSizeLabel {
    if (totalSizeBytes < 1024 * 1024) {
      return '${(totalSizeBytes / 1024).toStringAsFixed(1)} KB';
    }
    return '${(totalSizeBytes / (1024 * 1024)).toStringAsFixed(2)} MB';
  }
}
