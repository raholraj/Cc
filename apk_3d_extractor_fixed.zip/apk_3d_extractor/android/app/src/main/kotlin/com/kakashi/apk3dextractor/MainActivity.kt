package com.kakashi.apk3dextractor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
